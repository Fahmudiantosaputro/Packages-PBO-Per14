/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pertemuanketigabelas;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author mursi
 */
@Entity
@Table(name = "login")
@NamedQueries({
    @NamedQuery(name = "Login.findAll", query = "SELECT l FROM Login l"),
    @NamedQuery(name = "Login.findByUsername", query = "SELECT l FROM Login l WHERE l.username = :username"),
    @NamedQuery(name = "Login.findByPassword", query = "SELECT l FROM Login l WHERE l.password = :password")
})
public class Login implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Basic(optional = false)
    @Column(name = "username")
    private String username;

    @Basic(optional = false)
    @Column(name = "password")
    private String password;

    // 🔥 Tambahan field keamanan
    @Column(name = "makanan_favorit")
    private String makananFavorit;

    @Column(name = "lagu_favorit")
    private String laguFavorit;

    public Login() {
    }

    public Login(String username) {
        this.username = username;
    }

    public Login(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // Getter Setter Username
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    // Getter Setter Password
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // 🔥 Getter Setter Makanan Favorit
    public String getMakananFavorit() {
        return makananFavorit;
    }

    public void setMakananFavorit(String makananFavorit) {
        this.makananFavorit = makananFavorit;
    }

    // 🔥 Getter Setter Lagu Favorit
    public String getLaguFavorit() {
        return laguFavorit;
    }

    public void setLaguFavorit(String laguFavorit) {
        this.laguFavorit = laguFavorit;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (username != null ? username.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Login)) {
            return false;
        }
        Login other = (Login) object;
        if ((this.username == null && other.username != null)
                || (this.username != null && !this.username.equals(other.username))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pertemuanketigabelas.Login[ username=" + username + " ]";
    }
}
